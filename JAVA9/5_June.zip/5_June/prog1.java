
class Nisarg {

	public static void main(String[] args){

		System.out.println("Chakri Vadal");
	}
}
/*
suru@Suvarna:~/Core2web/JAVA9/Lecture code/5JUNE$ vim program1.java
suru@Suvarna:~/Core2web/JAVA9/Lecture code/5JUNE$ javac program1.java
suru@Suvarna:~/Core2web/JAVA9/Lecture code/5JUNE$ java Nisarg
Chakri Vadal
suru@Suvarna:~/Core2web/JAVA9/Lecture code/5JUNE$ 
*/

