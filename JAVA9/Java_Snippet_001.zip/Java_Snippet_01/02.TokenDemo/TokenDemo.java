



class TokenDemo {
	public static void main(String[] args) {
		String name ="Suwarna";
		int age = 22;
		System.out.println("Name ="+name);
		System.out.println("Age =" +age);
	}
}
/*
 here,
 identifiers= TokenDemo, name,age
 keywords = class, public, static,int, string
 */
