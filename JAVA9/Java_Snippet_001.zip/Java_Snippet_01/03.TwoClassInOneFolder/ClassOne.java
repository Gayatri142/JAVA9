


public class ClassOne {
	public void DisplayInfoOne() {
		System.out.println("Hello Everyone");
		System.out.println("This Method Is From ClassOne");
	}
}
