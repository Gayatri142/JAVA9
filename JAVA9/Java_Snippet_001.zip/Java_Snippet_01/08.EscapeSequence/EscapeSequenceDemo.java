


class EscapeSeq{

	public static void main(String[] args){

		//'\n'-> To insert new line
		System.out.println("This is new line -> \n I am on new line now");

		//'\b' -> inserts a backspace
		System.out.println("This is backspace ->\b");

		//'\t' -> inserts a tab
		System.out.println("This is tab ->\t I am after tab now");

		// '\r' -> carriage returns
		System.out.println("This is carriage return now see the 'T' at the start of this string is missing ->\r");

		// 'f' -> form feed
		System.out.println("This is formeed ->\f I am here");

		// \' -> This inserts a single quote in a string
		System.out.println("This is a single quote -> \'");

		// \" -> This inserts a double quote in the string
		System.out.println("This is new line -> \" ");
		
		// \\ -> This inserts a back slash in the string
		System.out.println("This is new line -> \\ ");
	
	}
}


