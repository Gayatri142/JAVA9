



class LongDataType{

        public static void main(String[] args){

                long num = 10l;

                System.out.println("Num = "+ num);
                System.out.println("Long Size ="+ Long.SIZE);
                System.out.println("Maximum Size of Long = "+ Long.MAX_VALUE);
                System.out.println("Minimum Size of Long = "+ Long.MIN_VALUE);

        }
}



