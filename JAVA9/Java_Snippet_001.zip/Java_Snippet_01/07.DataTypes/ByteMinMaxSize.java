


class ByteDataType{

	public static void main(String[] args){

		byte num = 10;

		System.out.println("Num = "+ num);
		System.out.println("Byte Size ="+ Byte.SIZE);
		System.out.println("Maximum Size of byte = "+ Byte.MAX_VALUE);
		System.out.println("Minimum Size of byte = "+ Byte.MIN_VALUE);

	}
}

