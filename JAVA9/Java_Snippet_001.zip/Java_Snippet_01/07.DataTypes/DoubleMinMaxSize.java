



class DoubleDataType{

        public static void main(String[] args){

                double num = 10d;

                System.out.println("Num = "+ num);
                System.out.println("Double Size ="+ Double.SIZE);
                System.out.println("Maximum Size of Double = "+ Double.MAX_VALUE);
                System.out.println("Minimum Size of Double = "+ Double.MIN_VALUE);

        }
}


