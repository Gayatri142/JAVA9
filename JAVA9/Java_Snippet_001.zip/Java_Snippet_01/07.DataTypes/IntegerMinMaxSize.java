




class IntDataType{

        public static void main(String[] args){

                int num = 10;

                System.out.println("Num = "+ num);
                System.out.println("Integer Size ="+ Integer.SIZE);
                System.out.println("Maximum Size of Integer = "+ Integer.MAX_VALUE);
                System.out.println("Minimum Size of Integer = "+ Integer.MIN_VALUE);

        }
}



