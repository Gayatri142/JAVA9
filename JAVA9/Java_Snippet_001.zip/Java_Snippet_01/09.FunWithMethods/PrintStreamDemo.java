



class PrintStatements{
	public static void main(String[] args){

		// This does not takes the cursor to the next line
		System.out.println("Core 2 web");

		//This takes the cursor to the next line...
		System.out.println("Core 2 Web again...");

		//This concats the num at the end of the String instead of adding 10+20 =30
		System.out.println("10" + 20);

		//This adds the values as the 10 and 20 both are integers
		System.out.println(10 + 20);

		//Did You Know? printf() like function in c is supported in java like follows
		System.out.printf("num1 : %d\t num2 : %d\t addition :%d\n",10,20,10 + 20);

		//String formating example...this is how you can insert int between strings
		System.out.println("John is "+ 20 + " years old man born in" + 1999);

	}
}
