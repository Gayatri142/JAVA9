



class FunColors{

	static String RED ="/u001B[31m";
	static String RESET ="/U001B[0m";
	static String GREEN ="/u001B[32m";

	public static void main(String[] args){

		// These are ANSI color codes that change our terminal colors....
		System.out.println(RED + "Im red Core2Web Technologies" +RESET);
		System.out.println(GREEN + "Im green Core2Web Technologies" +RESET);
	
	}
}
