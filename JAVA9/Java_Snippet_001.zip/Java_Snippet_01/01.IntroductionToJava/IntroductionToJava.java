




class MyFirstProgram {
	public static void main(String[] args) {
		System.out.println("Hello I am Gayatri \n");
		System.out.println("From Satara \n");
		System.out.println("welcome To Core2Web Family !!!");
	}
}

