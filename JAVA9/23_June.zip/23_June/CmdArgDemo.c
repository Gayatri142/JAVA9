


#include<stdio.h>
void main(int argc,char** argv) {
	 printf("%d\n",argc);// argc ha argument count asto to command line che total argument pass kelyat tyacha count deto including ./a.out
	 printf("%s\n",argv[0]);
	 printf("%s\n",argv[1]);
	 printf("%s\n",argv[2]);// argv ha argument variable aahe to command line through dilele Sting print karto
	}

