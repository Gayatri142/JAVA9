class BCCI {
	
	static int a=10;
	void impDecision(){
		System.out.println("Decision");

	}
	public static void main(String[] args){
		System.out.println(a);
//		BCCI obj1 = new BCCI();
//		obj1.impDecision();

		IPL obj2 = new IPL();
		obj2.emergingplayer();
	}
}
/*Explanation

jevha bcci complie keli tyanatr ipl chi pn .class file bnli ti mhnje kshi
- tr bcci mdhe ipl obj bnvlela hota so to shejari as ipl navacha class sodhayvh try krto tyala ti bhetli ki to compile krto
mhnun apn ipl commpil n krta .class file tyachipn bnli 
*/

