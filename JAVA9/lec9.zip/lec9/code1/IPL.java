class IPL {

	void emergingplayer() {

		System.out.println("Young cricketers");
		//System.out.println(a);
		System.out.println(BCCI.a);

		//BCCI xyz = new BCCI();
		//xyz.impDecision();
	}
}

