




class BCCI {
        static int a=10;
        void impDecision(){
                System.out.println("Decision");
        }
        public static void main(String[] args){
                BCCI obj2 = new BCCI();
                obj2.impDecision();

                IPL obj1 = new IPL();
                obj1.emergingPlayer();
        }

}

