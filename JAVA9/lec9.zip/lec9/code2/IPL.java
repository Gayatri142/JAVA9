


class IPL{
	void emergingPlayer(){

		System.out.println("Young Cricketers");
		//System.out.println(BCCI.a);
	}
}
