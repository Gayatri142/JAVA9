


// command line program
class Sush{

	public static void main(String[] movies) {

		System.out.println(movies[0]);  //  It will print the movie enter through command line of that index
		System.out.println(movies[1]);
	       System.out.println(movies[2]); 	
	}
}

