


class StudentInfo{

	int CS_Student1 = 50;
	int CS_Student2 = 47;

	public static void main(String[] args) {

		StudentInfo obj = new StudentInfo();

		//System.out.println(CS_Student1);
		System.out.println(obj.CS_Student1);
		System.out.println(obj.CS_Student2);
	}
}

