class Actor {

	public static void main(String[] args){
		System.out.println("Hritik Roshan");
		System.out.println("Irfan Khan");
		Actor obj = new Actor();
		obj.movies();
	}
	void movies(){
		System.out.println("Kaho na pyar hain");
		System.out.println("Piku");
	}
}
