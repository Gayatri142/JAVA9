
class Flat {

	int x=10;
	static int y=20;

	public static void main(String[] args){

		System.out.println("Static Demo");
	}
}
