class Year2020 {
	
	Year2020() {

		System.out.println("In consturctor");
	}
	public static void main(String[] args){
		
		Year2020 obj = new Year2020();
		System.out.println("Denger!!!!!");

	}
}
