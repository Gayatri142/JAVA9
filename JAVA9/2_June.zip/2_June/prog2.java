// how to write without main 

class WithoutMain {
	//static block     ha main chya adhi call hoto 
	static {
		System.out.println("In Static Block");
	}
	public static void main(String[] args) {
		System.err.println("In Main");
	}
}
/*
  so yachya next la version cheng kely 18 mdhe he hot without main chakt nahi
  so go to the 11 version
*/
