


#include<stdio.h>

void main(){
	 
	int x=15;

	int ans=0;

	ans=x<<3;

	printf("%d\n",ans); // 120
}
