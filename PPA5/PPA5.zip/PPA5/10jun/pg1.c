


#include<stdio.h>

void main(){
	 
	int x=10;

	int y=15;

	int ans=0;

	ans=x & y;

	printf("%d\n",ans); // 10
}
