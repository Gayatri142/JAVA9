#include<stdio.h>
void main(){
	printf("shubhada gaikwad\n");
	printf("Tssm's Bscoer\n");
	printf("Core2web\n");
}
