#include<stdio.h>
void main(){

	int a,b;

	printf("Enter number a : \n");
	scanf("%d",&a);

	printf("Enter number b :\n");
	scanf("%d",&b);
	
	printf("a = %d\n",a);
	printf("b = %d\n",b);
}
