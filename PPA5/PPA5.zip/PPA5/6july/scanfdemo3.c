#include<stdio.h>
void main(){

	int a,b;
	int ans;
	
	printf("Enter number for a and b :\n");
	scanf("%d %d",&a,&b);
	
	ans=a+b;
	
	printf("Ans = %d\n",ans);

}
