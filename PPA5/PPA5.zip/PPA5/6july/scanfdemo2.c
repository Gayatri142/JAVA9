#include<stdio.h>
void main(){

	int a,b;

	printf("Enter number for a and b :\n");
	scanf("%d %d",&a,&b);

	printf("a = %d\n b= %d\n",a,b);

}
