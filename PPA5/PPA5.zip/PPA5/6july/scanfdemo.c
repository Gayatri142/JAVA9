#include<stdio.h>
void main(){

	int a;

	printf("Enter number: \n");
	scanf("%d",&a);

	printf("a = %d\n",a);
}
