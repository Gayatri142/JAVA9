#include<stdio.h>
void main(){
	printf("myfunction\n");
	void swiggy(){
	printf("order food\n");
	}	
	void map(){
	printf("get location\n");
	}
	int budget(){
	printf("Money\n");
	}
	double makeup(){
	printf("ready\n");
	}
	swiggy();
	map();
	budget();
	makeup();
	
}
