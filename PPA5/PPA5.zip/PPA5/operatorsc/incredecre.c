#include<stdio.h>
void main(){
	int a=10,ans=0;
	ans=a++;
	//10 11

	printf("%d %d",a,ans);
}
