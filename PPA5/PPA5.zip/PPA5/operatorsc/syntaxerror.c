#include<stdio.h>
	void main(){
		int a=5,b=10,ans=0;
		a++;
		++b;
		5++;
	}
