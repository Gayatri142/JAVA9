#include<stdio.h>

void main(){

	int a=10;

	if(a == 10)		//True
		printf("Equal\n");
		printf("End of if\n");
}
