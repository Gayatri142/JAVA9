#include<stdio.h>

void main(){

	int marks=89;

	if(marks > 90){ 	//False

		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");
	}

	printf("NewT-shirt");

}


