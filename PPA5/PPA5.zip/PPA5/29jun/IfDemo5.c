#include<stdio.h>

void main(){

	int marks=93;

	if(marks > 90){ 	//True

		printf("Laptop\n");
		printf("Bike\n");
		printf("Watch\n");
	}

	printf("NewT-shirt");

}


