#include<stdio.h>
void main(){
	int a=10,ans=0;
	//preincrement
	// ans=++a;
	// printf("%d %d \n",a,ans);//11 11
	
	 //postincre
	// ans=a++;
	// printf("%d %d \n",a,ans);//11 10
	
	//predecre
	//ans=--a;
	// printf("%d %d \n",a,ans);//9 9
	

	//postdecre
	ans=a--;
	 printf("%d %d \n",a,ans);//9 10

}
