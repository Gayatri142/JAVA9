#include<stdio.h>
void main(){
	int x=10;
	int 10=y;

	printf("%d\n",x);
	printf("%d\n",x);
}
