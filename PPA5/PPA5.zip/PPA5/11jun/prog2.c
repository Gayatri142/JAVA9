

#include<stdio.h>

void main(){
	 	
	int x = 220;

	int ans = 0;

	ans= x >> 4;

	printf("%d\n",ans); //13
}
