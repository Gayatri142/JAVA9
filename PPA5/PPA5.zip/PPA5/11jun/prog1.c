

#include<stdio.h>

void main(){
	 	
	int x = 35;

	int ans = 0;

	ans= x >> 3;

	printf("%d\n",ans); //4
}
