 #include<stdio.h>

void main(){

	int x=(10,20,30,40,50);

	printf("%d\n",x);
}
