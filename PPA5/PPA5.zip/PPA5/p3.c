#include<stdio.h>
void main(){
	int a;
	float b;
	char c;
	double d;
	void v;
       	printf("%ld\n",sizeof(a));
       	printf("%ld\n",sizeof(b));
       	printf("%ld\n",sizeof(c));
       	printf("%ld\n",sizeof(d));
       	printf("%ld\n",sizeof(v));
}
