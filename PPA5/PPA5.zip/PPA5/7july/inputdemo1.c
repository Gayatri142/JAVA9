#include<stdio.h>
void main(){
	float val;
	printf("enter float value\n");
	scanf("%f",&val);  //20.5

	printf("%f\n",val);//20.500000
}
