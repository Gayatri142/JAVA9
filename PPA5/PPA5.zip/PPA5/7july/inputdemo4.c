#include<stdio.h>
void main(){

	char ch;

	printf("Enter character:\n");
	scanf("%c",&ch);

	printf("%c\n",ch);
	printf("%d\n",ch);

}
