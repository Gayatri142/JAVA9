//int float char

#include<stdio.h>
void main(){

	int x;
	float f;
	char ch;


	printf("enter value for char\n");
	scanf("%c",&ch);

	printf("enter value for int\n");
	scanf("%d",&x);

	printf("enter valu for float\n");
	scanf("%f",&f);

//      printf("enter value for char\n");
//	scanf("%c",&ch);

	printf("int value=%d\n",x);
	printf("float value=%f\n",f);
	printf("char value=%ch\n",x);
}



