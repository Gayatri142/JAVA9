#include<stdio.h>
void main(){
	int stud1Age=23;
	int stud2Age=20;
	int stud3Age=18;
	int AverageAge;
	AverageAge=stud1Age+stud2Age+stud3Age;
	printf("%d\n",AverageAge);
	
}
