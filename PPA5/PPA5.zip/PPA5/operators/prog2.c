#include<stdio.h>
void main(){
	
	int x=20;

	printf("%d\n",x);//20
	printf("%d\n",--x);//19
	printf("%d\n",x--);//19
	printf("%d\n",x);//18

}
