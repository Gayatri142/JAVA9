#include<stdio.h>

void main(){

		char ch ='d';

		switch(ch){

			case 'A' :
				printf("Case-A\n");
				break;

			case 'B' :
				printf("Case - B\n");
				break;

			case 'c':

				printf("Case-C\n");
				break;
			case 'd':
				printf("Case-D\n");
				break;

			default :
				printf("default case\n");
		}
}
