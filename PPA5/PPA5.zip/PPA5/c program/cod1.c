#include<stdio.h>
void main(){
	int a=12;
	a=a+1;
	++a;
	a=a+1;
	printf("%d\n",a);
}
