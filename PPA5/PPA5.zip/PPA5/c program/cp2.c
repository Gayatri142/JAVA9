#include<stdio.h>
void main(){
	int rollno;
	char Name;
	float marks;
	printf("enter value:\n");
	scanf("%d\n",&rollno);
	scanf("  %c\n",&Name);
	scanf("%f\n",&marks);

	printf("rollno:%d\n",rollno);
	printf("Name:%c\n",Name);
	printf("marks:%f\n",marks);
}
	
