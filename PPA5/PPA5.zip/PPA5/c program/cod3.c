#include<stdio.h>
void main(){
	int a=12;
	a=a++ + a++;
	printf("%d\n",a);
}
