#include<stdio.h>
void main(){
	int first,second,Third;
	printf("enter value:\n");
	scanf("%d",&first);
	scanf("%d",&second);
	scanf("%d",&Third);

	printf("first value=%ls\n",&first);
	printf("second value=%ls\n",&second);
	printf("Third value=%ls",&Third);
	
	printf("first value=%p\n",&first);
	printf("second value=%p\n",&second);
	printf("Third value=%p\n",&Third);
}

