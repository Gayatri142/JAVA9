//Null Statement

#include<stdio.h>

void main(){

	printf("core2web\n")//null statement ';'expected
		;
}
