//declaration statement


#include<stdio.h>

void main(){

	extern int a=20;

	print("%d\n",a);

}
