//defination statement


#include<stdio.h>

void main(){

	int a;    //declaration x
	int b=20; //defination

	printf("%d\n",a);//a
	printf("%d\n",b);//20

	printf("%ld\n",sizeof(a));//4
	printf("%ld\n",sizeof(b));//4
}


