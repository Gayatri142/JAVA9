//declaration statement


#include<stdio.h>

void main(){

	extern int a;

	//print("%d\n",a);
	printf("%ld\n",sizeof(a));
}
