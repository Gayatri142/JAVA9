
#include<stdio.h>

void main(){

	int a = 10;

	else{
		printf("Both are same\n");
	}
}
