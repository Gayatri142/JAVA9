
#include<stdio.h>

void main(){

	int a=65;

	switch(a){

		case 'A':  //A =25
			printf("character A\n");
			break;
	}
	printf("outside switch\n");
}
