 


#include<stdio.h>

void main(){
	int a =1;
	char ch='s';
	float f=20.5;

	switch(a){

		case 1:
			printf("one\n");
			break;
	}

	printf("outside switch\n");
}



