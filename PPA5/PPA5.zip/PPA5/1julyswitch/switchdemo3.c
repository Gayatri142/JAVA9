//matching not 


#include<stdio.h>

void main(){
	int a = 2;

	
	switch(a){    //no error
		case 1:
			printf("inside switch\n");
	}

	printf("outside switch\n");
}



