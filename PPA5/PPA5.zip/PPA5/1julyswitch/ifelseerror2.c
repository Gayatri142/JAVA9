
#include<stdio.h>

void main(){

	int a = 10;

	if(a == 10){
		printf("a is 10\n");
	}
	else if(a>10){
		printf("a is greater\n");
	}
}
