
#include<stdio.h>

void main(){

	int a = 10;

	if(a == 10)
		printf("Both are same\n");
}
