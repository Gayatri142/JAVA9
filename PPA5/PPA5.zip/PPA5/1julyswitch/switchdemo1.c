
#include<stdio.h>

void main(){
	int a = 1;

	
	switch(a){    //no error

		printf("inside switch");
	}

	printf("outside switch");
}



