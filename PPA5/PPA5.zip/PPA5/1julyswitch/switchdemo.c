
#include<stdio.h>

void main(){
	int a = 1;

	//without expression and case
	switch(a){    //error


	}

	//without case
	switch(a){     //no error
	}
}
