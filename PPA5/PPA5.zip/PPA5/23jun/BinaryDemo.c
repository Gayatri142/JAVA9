
#include<stdio.h>

void main(){

	int a=48;
	int b=95;

	int ans=a+b;

	printf("%d\n",ans);
}
