
#include<stdio.h>


void main(){

	int a=35;
	int b=-35;
	int c=20;
	int d=-20;

	printf("%d\n",~(a)); //-36
	printf("%d\n",~(b)); //34
	printf("%d\n",~(c));//-21
	printf("%d\n",~(d));//19

}
