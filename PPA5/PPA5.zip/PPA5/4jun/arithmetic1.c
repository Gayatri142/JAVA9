#include<stdio.h>

void main(){
	int ans =0;
	ans=3+4*2;

	printf("%d",ans);  //11
}
