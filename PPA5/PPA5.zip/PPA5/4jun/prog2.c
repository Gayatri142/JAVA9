#include<stdio.h>

void main(){
	int ans=0;

	ans=34+12/4-45;
i
	printf("%d",ans);
}
