#include<stdio.h>

void main(){
	int x=1,y=0,ans=0;

	ans=x & y;
	printf("%d",ans); //0

	ans=x || y;
	printf("%d",ans); //1
}
