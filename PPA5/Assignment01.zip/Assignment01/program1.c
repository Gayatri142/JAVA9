

#include<stdio.h>

void main() {

	int num = 20;
	if(num>20){
		printf("num is greater than 20");
	}
	printf("num :%d\n",num);
}

// Here we have defined num = 20 and we check condition in 'if' as if(num >20)
// this condition gets true then it will print ("num is greater than 20")
// here condition of 'if' gets false so it will print as num:20 
