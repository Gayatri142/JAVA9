

#include<stdio.h>

void main() {

	Bool val = false, var = true;

	if(val);{
		printf("true");
	}

	if(var){
		printf("false");
	}
}
// it will not execute 
