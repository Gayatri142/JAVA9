

#include<stdio.h>

void main() {

	int ilc = 15, olc = 25;

	if(olc>ilc) {
		printf("olc:%d\n",olc);
	}

	if(ilc<olc) {
		printf("ilc:%d\n",ilc);
	}

	printf("olc : %d\n",olc);
	printf("ilc :%d\n",ilc);
}

// here in this program 
// In first If it will check that olc is greater than ilc or not the condition is true so it will print value of olc as 25
// In second If it will check that ilc is less than olc or not the condition is true so it will print value of ilc as 15 and it come out of if//It comes out of if and print the value of olc and ilc
// so output looks like
// olc :25
// ilc :15
// olc:25
// ilc:15 
