

#include<stdio.h>

void main() {

	int a = 20;
	
	if(a == 10) {
		printf("a equals 10\n");

	}
	else (a > 10){
		printf("a is greater\n");
	}
}
