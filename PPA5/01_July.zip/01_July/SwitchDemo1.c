

#include<stdio.h>

void main() {
	
	int a = 1;

	switch(a) {		// no error
		     printf("Inside Switch\n");
	}
	printf("Outside Switch\n");


}
