

#include<stdio.h>

void main() {

	int a = 65;

	switch(a) {

		case'B':				//A==65
			printf("Character A\n");
			break;
	}
	printf("OutsideSwitch\n");
}
