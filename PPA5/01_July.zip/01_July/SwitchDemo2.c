

// matching case

#include<stdio.h>

void main() {
	
	int a = 2;

	switch(a) { 		// no error
		case 1 :
		       printf("Inside Switch\n");
	}

	printf("Outside Switch\n");


}
