


#include<stdio.h>

void main() {

	char ch;
	printf("ASCII value from 1 to 128 :\n");
	
	for(int i = 1; i<= 128; i++) {

		printf(" ASCII vallue of character %c = %d\n",i,i);
	}
}

//ethe fist aapn statment  print karun ghetla printf through
//nantr for mde i = 1 kela ani i<=128 check kela true asel tr tya character or number or symbol chi ascii value print keli

