


#include<stdio.h>

void main () {

//	int n;
//	printf("Enter the numbers :\n");
//	scanf("%d",&n);

	for(char i = 'y'; i >= 'j'; i--) {

		printf("%c\n",i);
	
	}
}


// ethe for mde aapn i =y kela i>=j kela aani i-- cause aaplyala reverse print karaychy mhanun

