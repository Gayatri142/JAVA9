


#include<stdio.h>

void main() {

	printf("Odd Numbers between 20 to 40 :\n");

	for(int i = 20; i <=40; i++) {

		if(i % 2 != 0) {

			printf("%d \n",i);
		}
	}
}

// ethe aapn first odd numbers between 20 to 40 ashi line print karto 
// nantr for mde int i gheun 20 tyala assign karto 
// nantr condtion check karto i 40 peksha lahan kiva equal aahe ka 
// to lahan or equal asel tr aapn for chya aat yeun if condition check karto karan aaplyala odd no print karaychet
// jr if chi condition true zali eg 20%2 != 0 aata ethe he condition true hotiye so to if mde janar ani odd no print karnar
