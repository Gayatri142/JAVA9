


#include<stdio.h>

void main () {

//	int n;
//	printf("Enter the numbers :\n");
//	scanf("%d",&n);

	for(int i =30; i >=15;) {

		printf("%d\n",i);
		i=i-2;
	}
}

// ethe aapn i =30 initialize kela aani i>=15 condition check keli aani i aapn 2 ne decrement kela karan aaplyala alternate number reverse ne print karayche hote
