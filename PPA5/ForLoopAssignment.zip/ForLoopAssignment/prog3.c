


#include<stdio.h>

void main() {

	printf("Even  Numbers between 50 to 70 :\n");

	for(int i = 50; i <=70; i++) {

		if(i % 2 == 0) {

			printf("%d \n",i);
		}
	}
}

// ethe aapn first even numbers between 50 to 70 ashi line print karto
// nantr for mde int i gheun 50 tyala assign karto
// nantr condtion check karto i 70 peksha lahan kiva equal aahe ka
// to lahan or equal asel tr aapn for chya aat yeun if condition check karto karan aaplyala even no print karaychet
// jr if chi condition true zali eg 50%2 == 0 aata ethe he condition true hotiye so to if mde jato ani even no print karto
