

#include<stdio.h>
void main() {

	int a = 10, ans = 0;
	/*
	//preincrement
	
	ans = ++a;
	printf("PreIncrement = %d %d \n",a,ans);

	// postIncrement

	ans = a++;
        printf("PostIncrement = %d %d \n",a,ans);

	//predecrement
	
	ans = --a;
        printf("PreDecrement = %d %d \n",a,ans);
*/

	//postdecrement
	
	ans = a--;
        printf("PostDecrement = %d %d \n",a,ans);


}
