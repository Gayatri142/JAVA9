

#include<stdio.h>

void main(){

	int a=10;

	if(a != 10)		//False
		printf("Equal\n");
		printf("End of if\n");
}
