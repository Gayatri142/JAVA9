

#include<stdio.h>

void main() {

	int marks= 60;

	if(marks >= 98){

		printf("FC\n");
	}else if(marks >= 80 && marks <= 98){

		printf("Modern\n");
	}else if(marks >= 70 && marks <= 88){

	       printf("Garware\n");
	}else{
		printf("Jaykranti\n");	
	}
}

