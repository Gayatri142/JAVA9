

#include<stdio.h>

void main() {

	int userName = 123;
	int password = 456;

	if(userName == 123 && password == 456) {
		printf("Successfully Login\n");
	} else {
		printf("Invalid userName or password\n");
	}
}
