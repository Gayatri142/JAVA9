

#include<stdio.h>

void main() {

	int x,y;
//	char ch ;

	printf("Enter two values\n");
	scanf("%d %d",&x,&y);
	
	//print("Enter operator :\n");
	//scanf("%c",&ch);

	if(x = y)
		printf("True\n");
	printf("Out Of If\n");
}
