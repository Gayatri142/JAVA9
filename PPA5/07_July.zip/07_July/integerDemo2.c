

#include<stdio.h>

void main() {

	float val1,val2;

	printf("Enter two values for float\n");
	scanf("%f %f",&val1,&val2);

	printf("Val = %f \n Val2 = %f\n",val1,val2);
}
