

// int, float,char


#include<stdio.h>

void main() {

	int x;
	float f;
	char ch;


	printf("Enter values for int :\n");
	scanf("%d",&x);				//10
	 
	printf("Enter values for float :\n");	
	scanf("%f",&f);				//20.5

	printf("Enter values for char :\n");
        scanf(" %c",&ch);			//A

	
	printf("Int value = %d\n",x);
	printf("Float value = %f\n",f);
	printf("Char value = %c\n",ch);

}
