

#include<stdio.h>
void main() {
	int a = -35;

	printf("%d\n",a);
}

