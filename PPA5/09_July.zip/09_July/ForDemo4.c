

#include<stdio.h>

void main() {

	for(int i = 1; i <= 20; i++) {

		if(i % 5 == 0) {

			printf("Number is Divisible :%d\n",i);
		}else {

			printf("Number is Not Divisible :%d\n",i);
		}

	}
}
