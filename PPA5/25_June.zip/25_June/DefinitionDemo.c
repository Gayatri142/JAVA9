
#include<stdio.h>
void main() {
	int a;
	int b = 20;

	printf("%d\n",a); //0
	printf("%d\n",(b)); //20
	printf("%d\n",sizeof(a));//4
	printf("%d\n",sizeof(b));  //4
}

