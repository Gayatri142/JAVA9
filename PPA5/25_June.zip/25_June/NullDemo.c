

#include<stdio.h>
void main(){

	printf("\n Core2Web");

	;

	printf("\n BiEncaps");
}
