


#include<stdio.h>

void main() {

	int x = 10;

	switch(x) {

		case 9:{
				int x = 20;
				int y = 30;
				printf("%d\n",x+y);
			}
			break;
		case 10:{
				int x = 20;
				int y = 30;
				printf("%d\n",x-y);
			}
			break;
			

	}
}
