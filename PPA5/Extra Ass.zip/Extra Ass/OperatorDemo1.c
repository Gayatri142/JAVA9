

#include<stdio.h>

void main() {

	int x =10;
	int ans = 0;

	ans = x >> 2;

	printf("%d\n",ans);
}
