

#include<stdio.h>

void main() {

	int x = 5, y = 6;
	int ans = 0;

	ans = x && y;
	printf("%d\n",ans);
}

