#include<stdio.h>
void main(){
	int i = 3, j;
	j = i++;
	printf("%d,%d",i,j);
}
