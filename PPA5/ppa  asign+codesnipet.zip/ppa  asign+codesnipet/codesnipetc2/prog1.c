#include<stdio.h>
void main(){
	int i = 10,j =10,k;
	k= ++i + j ++;
	printf("%d,%d,%d",i,j,k);
}
