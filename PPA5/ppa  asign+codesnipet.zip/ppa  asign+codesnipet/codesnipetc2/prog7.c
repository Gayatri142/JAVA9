#include<stdio.h>
void main(){
	int x =12,y=7,z;
	z= x !=4 || y == 2;
	printf("z=%d\n",z);
}
