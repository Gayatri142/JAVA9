#include<stdio.h>
void main(){

	int num =7;
	num = num/4;
	printf("%d\n",num);
}
