#include<stdio.h>
void main(){
	int a =20,b=15,c=5;
	int d;
	d = a == (b+c);
	printf("%d",d);
}
