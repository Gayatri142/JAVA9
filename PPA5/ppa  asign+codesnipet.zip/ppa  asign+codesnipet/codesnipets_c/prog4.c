#include<stdio.h>
void main(){
	int num= 4 * 5 / 2 + 9;
	printf("%d\n",num);
}
