#include<stdio.h>
void main(){
	int i=10,j;
	j=++i;
	printf("%d,%d",i,i);
}
