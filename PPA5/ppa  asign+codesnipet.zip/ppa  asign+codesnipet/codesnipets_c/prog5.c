#include<stdio.h>
void main(){
	int x =4.3 %2;
	printf("value of x is %d",x);
}
