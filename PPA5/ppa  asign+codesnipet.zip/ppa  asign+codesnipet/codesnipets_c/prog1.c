#include<stdio.h>
void main(){
	int i = -5;
	int num = i%4;
	printf("%d\n",num);
}
