#include<stdio.h>
void main(){
	int a =20;
	double b =15.6;
	int c;
	c =a+b;
	printf("%d",c);
}
