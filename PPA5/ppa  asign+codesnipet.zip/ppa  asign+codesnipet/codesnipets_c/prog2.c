#include<stdio.h>
void main(){
	int i =5;
	int num1 =i / -4;
	int num2 = i % -4;
	printf("%d %d\n",num1,num2);
}
