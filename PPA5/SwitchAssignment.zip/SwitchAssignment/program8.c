

#include<stdio.h>

void main() {
	
	int a;
	printf("Enter the number :\n");
	scanf("%d",&a);

	if(a > 5) {

		printf("%d  is greater than 5\n",a);
	}else {
		printf("%d\n",a);
	}
}
