

#include <stdio.h>

void main() {
	int a= 10;
	switch(a) {
		case 1:
			printf(“Hello\n”);
			break;
		case 2:
			printf(“Hii\n”);
			break;
		default:
			printf(“Default case\n”);
	}
}
