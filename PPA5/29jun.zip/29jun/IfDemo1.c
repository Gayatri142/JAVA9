#include<stdio.h>

void main(){

	int a = 5;

	if(a<10) //True
		printf(" 10  is greater");

}
