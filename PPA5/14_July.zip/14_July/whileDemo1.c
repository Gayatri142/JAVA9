

#include<stdio.h>

void main() {

	int i = 65;			// initialization

	while(i<=90) {			// condition

		printf("%c\n",i); //statement
		i++;			// inc/decre
	}
}
