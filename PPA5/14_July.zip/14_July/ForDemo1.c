


#include<stdio.h>

void main() {

	for(char ch = 'A'; ch<='Z'; ch++) {

		printf("%c\n",ch);
	}
}
