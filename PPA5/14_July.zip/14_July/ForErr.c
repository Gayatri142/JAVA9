

#include<stdio.h>

void main () {

	// for(initialization; condition; increment/decrement){
	// statement;
	// }
	

	int i = 97;		// initialization
	
	for( ;i <= 122;) {	//condition

		printf("%c\n",i);	//statement
		i++;			// increment or decrement as statement
	
	}
}
