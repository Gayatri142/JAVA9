

// by comparing ASCII value print character


#include<stdio.h>

void main() {

	for(int i = 65; i <= 90; i++) {

		printf("%c\n",i);
	}
}
