


#include<stdio.h>

void main() {

	int num;

	printf("Enter Integer value :\n"); // enter a number by user
	scanf("%d", &num);		   // accept that number

	printf("You Entered Integer Value: %d\n", num); // print the statement and number

}



