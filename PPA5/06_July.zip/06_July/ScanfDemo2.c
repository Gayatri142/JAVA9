

#include<stdio.h>

void main() {

	int a,b;

	printf("Enter the Number for a and b: \n");
	scanf("%d %d",&a,&b);

	printf("A =%d\nB =%d\n",a,b);



	
}
