

#include<stdio.h>

void main() {

	int a,b,ans;

	printf("Enter the Number for a and b: \n");
	scanf("%d %d",&a,&b);

	ans = a + b;

//	printf("Ans = %d\n",a+b);	// without storing ans value
	printf("Ans = %d\n",ans);	// storing the ans in third variable


	
}
