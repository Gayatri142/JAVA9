

#include<stdio.h>

void main() {

	int a,b;

	printf("Enter the Number for a: \n");
	scanf("%d",&a);


	printf("Enter the Number for b: \n");
	scanf("%d",&b);

	printf("A = %d\n",a);
	printf("B = %d\n",b);


	//printf("Address of a = %p\n",a);
	//printf("Address of a = %p\n",a);
}
